import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
console.log('main');

//Variables pre etablis en js 
console.log(`
    Hauteur page : ${document.body.scrollHeight}
    Hauteur affichage : ${innerHeight}
    Scroll Position : ${scrollY}`
);

const divBar = document.querySelector(".bar")

//on le fait en le total de le doucment
document.addEventListener("scroll", () => {
    let scrollMax = document.body.scrollHeight - innerHeight; 
//console.log(scrollMax);
    let onEstOu = (scrollY / scrollMax) * 100; 
//console.log(+ onEstOu + "%" );
    divBar.style.width = onEstOu + '%'; 
})


const monTxt = document.querySelector('textarea'); 
let rendu = document.querySelector('#renderTextEdit');
monTxt.addEventListener("keyup", () =>{
    rendu.innerText = monTxt.value;
})

//marked 
