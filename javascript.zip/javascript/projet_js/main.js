/*import './style.css'
import javascriptLogo from './javascript.svg'
import viteLogo from '/vite.svg'
import { setupCounter } from './counter.js'

document.querySelector('#app').innerHTML = `
  <div>
    <a href="https://vitejs.dev" target="_blank">
      <img src="${viteLogo}" class="logo" alt="Vite logo" />
    </a>
    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank">
      <img src="${javascriptLogo}" class="logo vanilla" alt="JavaScript logo" />
    </a>
    <h1>Hello Vite!</h1>
    <div class="card">
      <button id="counter" type="button"></button>
    </div>
    <p class="read-the-docs">
      Click on the Vite logo to learn more
    </p>
  </div>
`

setupCounter(document.querySelector('#counter'))
*/

let varString = "Hello world";
let varNombre = 65;
let varNombreVirgule = 2.36;
let varTableau = [23, "Hello", 96, "World"];
let varObjet = {
  firstName: "Fuertes",
  name:"Sofia",
  age: 30,
}; 

console.log(varString);
console.log(varNombre);
console.log(varNombreVirgule);
console.log(varTableau);
console.log(varObjet);
console.log(varObjet.firstName);

//Exercice Calculs - Nombres
let nombre1= 56;
let nombre2= 32.8;
let nombre3= 902;
let nombre4= 4.2;


console.log((nombre1*nombre2)+3);
console.log(nombre3/nombre1);
console.log(nombre4+=nombre2);
console.log(nombre4+=20);

nombre3++;
console.log(nombre3)
console.log((50/10)*nombre4-(nombre2-=8));
nombre1--;
console.log(nombre1);

console.log("0.1 + 0.2 =", (0.1+0.2).toFixed(1));
console.log("0.1 + 0.2 =", (0.1+0.2));

//Concatenation
let bonjour = 'Bonjour';

let unMessage = "Bienvenue";

let welcome = `Bienvenue`;

console.log(bonjour + unMessage + welcome);

//Exercice Phrase

let nom = "Lara";
let pizza = "Margharita"
let date = "15 Julliet"
let heure = "20h55 "
let tempsAttend = 40;
let blague = `Qu'est-ce qu'une pizza a dit à une autre pizza qui lui demandait des conseils?\n"Suis ta pâte et tout ira bien !"\n `;
let merci = `Merci d'avoir commandé chez "La pizzeria Raffinata"`;

let sumUpOrderPhrase = "Bonsoir " + nom + ", vous avez commandé une pizza " + pizza + ' le ' + date + " à " + heure + ". La commande sera livrée en " + tempsAttend + " minutes. \n" + blague + merci;
console.log(sumUpOrderPhrase);

let sumUpOrder = `Bonsoir ${nom},
Vous avez commandé une pizza ${pizza} le ${date} à ${heure}.
La commande sera livrée en ${tempsAttend} minutes.

${blague} 
${merci}`; 
console.log(sumUpOrder);

//Exercice Tableaux
let nom1= "Emma";
let age= 30;
let passions= ["Football", "Céramique"]; 

let tabUser = [nom1, age, passions]; 

console.log(tabUser);
console.log(tabUser[2]); 
console.log(tabUser[2][1]);

//Exercice tableaux 2
console.log("Exercice Tableaux 2");
let trucs= [50, "Hello", 63, "Argentina"]; 
trucs.push("Messi");
console.log(trucs);

//Exercice tableaux 3
console.log("Exercice Tableaux 3");
let leNom = "Messi";
let lePrenom = "Lionel"
let laPhrase = []; 
laPhrase.push(leNom, lePrenom, lePrenom[0], leNom[0]);
console.log(laPhrase);