//!-------INTRO JS LES CALCULS-------
//! Exo 2 Calculs : 
//TODO: Afficher différents résultats de calculs dans la console du navigateur

console.log(2**10);
console.log(20+33);
console.log(20-33);
console.log(20/33);
console.log(20*33);
// 🚨 Troll pour les décimales
console.log(2,33+10);
// Pour les décimales la virgule avec la notation en .
console.log(2.33+10);
console.log('LOL',10000);
console.log(0.1+0.2);
console.log(1+20*5);
console.log((1+20)*5);
console.log(10%2);
console.log(3%2);

// Incrémentation
let num = 0;
console.log(num+1);
//? Pour faire du Cumul : 
// num = num+1;
num +=1;//Notation raccourcie (assignation composé)
// num = num + 5;
num +=5;
// Notation raccourcie incrémentation de 1
console.log(num++);
console.log(num--);